<? require_once("./inc/pages/header.php"); ?>
<? require_once("./inc/pages/secondintro.php"); ?>
<? require_once("./inc/pages/quotes.php");?>
</div><!-- close header -->
<div id="contentWrapper">
	<div id="content">
		
		<div id="contact">
			<h1>Contact</h1>

			
			<p>Our top notch service will afford you, the customer, the luxury and peace of mind that all your "needs" are being taken care of. We encourage you to get in touch with the Jewel team so we can assist you.</p>
			<br/>
			<p>Telephone - (905) 665-1496<br/>
			Toll free - (877) 509-0505<br/>
			Fax - (905) 665-7606<br/>
			Email - <a href="mailto:team@jewelcomputers.com">team@jewelcomputers.com</a></br>
			</p>
		</div>
		
		<div id="contactImg">
			<img src="./images/contact.png">
		</div>
	</div>
</div>
<? require_once("./inc/pages/footer.php"); ?>	