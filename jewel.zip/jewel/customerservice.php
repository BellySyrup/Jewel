<? require_once("./inc/pages/header.php"); ?>
<? require_once("./inc/pages/secondintro.php"); ?>
<? require_once("./inc/pages/quotesblurbs.php");?>
<div id="content">
<h1>Customer Service</h1>
<div id="test"></div>
</div>
<? require_once("./inc/pages/footer.php"); ?>	