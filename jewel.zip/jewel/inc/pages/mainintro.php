<div id="intro">
	<div id="introContent">
		<img src="./images/logo_fullv2.png" id="logo" alt="logo"/>
		<img src="./images/home_header_image.png" id="headerImg" alt="header image"/>
	</div>
</div>