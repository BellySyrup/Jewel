<div id="secondintro">
	<div id="secondintroContent">
		<img src="./images/logo_fullv2.png" id="logo2" alt="logo"/>
		<img src="./images/other_pages_header_image.png" id="otherHeaderImg" alt="smaller header img" />
	</div>
</div>