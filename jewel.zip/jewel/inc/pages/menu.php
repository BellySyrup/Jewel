<div id="nav">
	<a href="contact.php" name="contact" class="nav">Contact</a>
	<a href="about.php" name="about" class="nav">About</a>
	<a href="services.php" name="services" class="nav">Services</a>
	<a href="manufacturers.php" name="manufacturers" class="nav">Manufacturers</a>	
	<a href="products.php" name="products" class="nav">Products</a>
	<a href="index.php" name="index" class="nav">Home</a>
</div>