			<div id="footer">
				<div id="footerNav">
					<a href="index.php" class="footerNav">Home</a>
					<a href="products.php" class="footerNav">Products</a>
					<a href="manufacturers.php" class="footerNav">Manufacturers</a>	
					<a href="services.php" class="footerNav">Services</a> 
					<a href="about.php" class="footerNav">About</a>
					<a href="contact.php" class="footerNav">Contact</a>
				</div>
				<p>Jewel Computer Brokers Inc.<br />&copy; 2012</p>
			</div>
		</div>
		<a href="#nav"><div class="returnTop">Back to Top</div></a>
	</body>
</html>